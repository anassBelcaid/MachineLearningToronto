function plot_model(w, w0, color)
ind1 = -5:0.005:5;
ind2 = -(w(1)*ind1+w0)./(w(2));
hold on; plot(ind1, ind2, color, 'LineWidth', 2);