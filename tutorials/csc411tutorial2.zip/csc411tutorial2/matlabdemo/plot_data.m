function plot_data(x, y)

scatter(x(y>0,1), x(y>0,2), 'r*'); hold on;
scatter(x(y==0,1), x(y==0,2), 'bx');xlabel('x_1');ylabel('x_2');
axis([-5 5 -5 5])
legend('class1', 'class2');