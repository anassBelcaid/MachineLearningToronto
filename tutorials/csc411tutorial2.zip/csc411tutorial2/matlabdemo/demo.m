clc;clear;clf;
rng(1);

% random points
n = 200;
x = randn(n, 2)*13 + 7;

% in general you want to scale the data first
x = x - repmat(mean(x),size(x,1),1);
x = x ./ repmat(std(x),size(x,1),1);

% ground truth - line by which we assign class labels
w_gt = [0.5; -0.2];
w0_gt = -0.1;
% create ground truth
y = (x*w_gt + w0_gt + randn(n, 1)*0) > 0.;

% initialize our classifier
w = [-1; 1];
w0 = randn(1)/10.;

% cross-entropy loss
losses = y .* log(sigmoid(x*w + w0) + eps) ...
   + (1-y) .* log(1 - sigmoid(x*w + w0) + eps);
sum_loss = -mean(losses);

% large/small learning rate
eta = .5;
%eta = 0.1;

% L2 regularization
lambda = 0.0001;
% lambda = 0.0001;
% lambda = 0;


max_iter = 50;

for i = 1 : max_iter
    % gradient of cross-entropy loss with L2 regularization
    grad = mean(repmat(sigmoid(x*w + w0) - y, [1, 3]).*horzcat(ones(n, 1),x), 1)' + lambda * [0; w];
    % update the weights
    w0_prev = w0;
    w_prev = w;
    w0 = w0 - eta * grad(1);
    w = w - eta * grad(2:3);
    
    losses = y .* log(sigmoid(x*w + w0) + eps) ...
       + (1-y) .* log(1 - sigmoid(x*w + w0) + eps);
    sum_loss = -mean(losses);
    y_test = (x*w + w0) > 0;
    train_err = sum(y~=y_test)/n;
    fprintf('Iteration %d, w0 = %2.2f, w = (%2.2f, %2.2f), loss = %f, training error = %f%%\n', i, w0, w(1), w(2), sum_loss, train_err*100);
    
    figure(1);
    hold on; plot_data(x, y);
    plot_model(w, w0, 'g');
    plot_model(w_gt, w0_gt, 'k-.');
    pause;
    clf;
    
    if (grad'*grad < 1e-5)
        fprintf('Done\n');
        break;
    end
end
% figure(1);
% hold on; plot_data(x, y);
% plot_model(w, w0, 'g');
% plot_model(w_gt, w0_gt, 'k-.');





